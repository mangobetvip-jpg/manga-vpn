from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Literal

app = FastAPI(title="Manga VPN API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["Authorization", "Content-Type"],
)

REGIONS = [
    {"id": "us-east", "name": "Estados Unidos — Leste", "country": "US", "status": "planned"},
    {"id": "us-west", "name": "Estados Unidos — Oeste", "country": "US", "status": "planned"},
    {"id": "ca", "name": "Canadá", "country": "CA", "status": "planned"},
    {"id": "de", "name": "Alemanha", "country": "DE", "status": "planned"},
    {"id": "uk", "name": "Reino Unido", "country": "GB", "status": "planned"},
]

class ConfigRequest(BaseModel):
    region_id: str
    device_name: str = Field(min_length=1, max_length=64)
    ip_type: Literal["shared", "dedicated"]

class ProxyRequest(BaseModel):
    url: str = Field(min_length=8, max_length=2048)

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "manga-vpn-api"}

@app.get("/api/regions")
def regions():
    return {"regions": REGIONS}

@app.post("/api/wireguard/config")
def create_wireguard_config(payload: ConfigRequest):
    if payload.region_id not in {r["id"] for r in REGIONS}:
        raise HTTPException(status_code=404, detail="Região não encontrada")
    # TODO: autenticar usuário, verificar plano, criar chaves por dispositivo,
    # alocar IP e provisionar peer. A chave privada deve ser gerada no cliente.
    raise HTTPException(status_code=501, detail="Provisionamento WireGuard ainda não conectado.")

@app.post("/api/proxy/session")
def create_proxy_session(payload: ProxyRequest):
    # Não transformar este endpoint em open proxy. Implementar allowlist,
    # bloqueio de redes privadas e endpoints de metadata, além de isolamento.
    raise HTTPException(status_code=501, detail="Proxy desativado até os controles de segurança.")
