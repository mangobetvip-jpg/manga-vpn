# Manga VPN — Starter
Base inicial de site web com React/Vite e API FastAPI.

## Executar
Backend:
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Frontend:
```bash
cd frontend
npm install
npm run dev
```
Abra http://localhost:5173. API em http://localhost:8000/docs.

## Estado
A interface é um protótipo funcional de navegação. A emissão de perfis WireGuard e o proxy ainda não estão ativados.
Antes de ativar o proxy, implementar autenticação, allowlist de destinos, bloqueio de IPs privados/loopback/link-local,
proteção contra SSRF e DNS rebinding, isolamento de sessões e limites de tráfego.
O provisionamento WireGuard precisa de servidores Linux próprios, geração segura de chaves, firewall e gestão de peers.
